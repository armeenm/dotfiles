{ config
, isHeadless
, isPortable
, enableSocial
, pkgs
, lib
, user
, ...
}:

let
  inherit (pkgs.stdenv) hostPlatform;
  opencode = import ./opencode.nix { inherit lib pkgs; };
in {
  programs = {
    aria2.enable = true;
    bacon.enable = true;
    bashmount.enable = hostPlatform.isLinux;
    bat.enable = true;
    bun.enable = true;
    carapace = {
      enable = true;
      # Let carapace use installed bash completions for commands it has no
      # spec for. Covered commands keep their native zsh completion; see
      # init.zsh for the restore pass.
      environment.CARAPACE_BRIDGES = "bash";
    };
    clock-rs.enable = true;
    dircolors.enable = true;
    direnv.enable = true;
    # TODO: Build is busted.
    # direnv-instant.enable = true;
    fastfetch.enable = true;
    git-worktree-switcher.enable = true;
    gitui.enable = hostPlatform.isLinux;
    home-manager.enable = true;
    htop.enable = true;
    imv.enable = hostPlatform.isLinux && !isHeadless;
    mpv.enable = hostPlatform.isLinux && !isHeadless;
    navi.enable = true;
    lesspipe.enable = true;
    nix-index-database.comma.enable = true;
    nix-init.enable = true;
    nix-your-shell.enable = true;
    noti.enable = !isHeadless;
    pay-respects.enable = true;
    ripgrep-all.enable = true;
    ripgrep.enable = true;
    scmpuff.enable = true;
    uv.enable = true;
    zoxide.enable = true;

    aerospace = {
      enable = !isHeadless && hostPlatform.isDarwin;
      launchd.enable = true;

      settings = let
        launch = x: "exec-and-forget open -n -a ${x}";
        sketchybar = "${config.programs.sketchybar.package}/bin/sketchybar";
      in {
        automatically-unhide-macos-hidden-apps = true;
        exec-on-workspace-change = [
          "${pkgs.bash}/bin/bash"
          "-c"
          "${sketchybar} --trigger aerospace_workspace_change FOCUSED_WORKSPACE=$AEROSPACE_FOCUSED_WORKSPACE"
        ];
        on-focus-changed = [ "move-mouse window-lazy-center" ];
        on-window-detected = [
          {
            "if".app-id = "net.whatsapp.WhatsApp";
            run = [ "layout tiling" ];
          }
          {
            "if".app-id = "org.alacritty";
            run = [ "layout tiling" ];
          }
          # {
          #   "if".app-name-regex-substring = "emacs";
          #   run = [ "layout tiling" ];
          # }
        ];

        gaps = {
          inner.horizontal = 8;
          inner.vertical = 8;
        };

        mode.main.binding = {
          alt-h = "focus --boundaries all-monitors-outer-frame left";
          alt-j = "focus --boundaries all-monitors-outer-frame down";
          alt-k = "focus --boundaries all-monitors-outer-frame up";
          alt-l = "focus --boundaries all-monitors-outer-frame right";

          alt-ctrl-h = "join-with left";
          alt-ctrl-j = "join-with down";
          alt-ctrl-k = "join-with up";
          alt-ctrl-l = "join-with right";

          alt-shift-h = "move --boundaries all-monitors-outer-frame left";
          alt-shift-j = "move --boundaries all-monitors-outer-frame down";
          alt-shift-k = "move --boundaries all-monitors-outer-frame up";
          alt-shift-l = "move --boundaries all-monitors-outer-frame right";

          alt-1 = "workspace 1";
          alt-2 = "workspace 2";
          alt-3 = "workspace 3";
          alt-4 = "workspace 4";
          alt-5 = "workspace 5";
          alt-6 = "workspace 6";
          alt-7 = "workspace 7";
          alt-8 = "workspace 8";
          alt-9 = "workspace 9";

          alt-shift-1 = "move-node-to-workspace 1";
          alt-shift-2 = "move-node-to-workspace 2";
          alt-shift-3 = "move-node-to-workspace 3";
          alt-shift-4 = "move-node-to-workspace 4";
          alt-shift-5 = "move-node-to-workspace 5";
          alt-shift-6 = "move-node-to-workspace 6";
          alt-shift-7 = "move-node-to-workspace 7";
          alt-shift-8 = "move-node-to-workspace 8";
          alt-shift-9 = "move-node-to-workspace 9";

          alt-tab = "workspace-back-and-forth";
          alt-space = "layout floating tiling";
          alt-f = "fullscreen";
          alt-r = "mode resize";
          alt-p = "exec-and-forget ${config.programs.emacs.finalPackage}/bin/emacsclient -c -n";
          alt-shift-enter = ''exec-and-forget ${config.programs.alacritty.package}/bin/alacritty msg create-window'';
        };

        mode.resize.binding = {
          esc = "mode main";
          enter = "mode main";
          backspace = "flatten-workspace-tree";
          b = "balance-sizes";

          h = "resize width -50";
          j = "resize height -50";
          k = "resize height +50";
          l = "resize width +50";
        };
      };
    };

    alacritty = {
      enable = !isHeadless;
      settings = {
        window = {
          blur = true;
          decorations = if hostPlatform.isDarwin then "Buttonless" else "Full";
          dynamic_padding = true;
          option_as_alt = "OnlyLeft";
          padding = { x = 20; y = 20; };
        };
      };
    };

    atuin = {
      enable = true;
      settings = {
        auto_sync = enableSocial;
        enter_accept = true;
        filter_mode_shell_up_key_binding = "session";
        inline_height = 30;
        invert = false;
        show_preview = true;
        style = "compact";
        update_check = false;
        workspaces = true;
      };
    };

    bash = {
      enable = true;
      historyFile = "${config.xdg.cacheHome}/bash/history";
    };

    beets = {
      # enable = hostPlatform.isLinux;
      package = pkgs.stable.beets;
      settings = {
        directory = config.xdg.userDirs.music;
      };
    };

    btop = {
      enable = true;
      settings = {
        rounded_corners = false;
        vim_keys = true;
        log_level = "WARNING";
      };
    };

    cava = {
      enable = hostPlatform.isLinux;
      settings = {
        general.framerate = 144;
      };
    };

    delta = {
      enable = true;
      enableGitIntegration = true;
      options = {
        line-numbers = true;
        syntax-theme = "base16-stylix";
        navigate = true;
      };
    };

    discord = {
      enable = enableSocial;
      settings = {
        DANGEROUS_ENABLE_DEVTOOLS_ONLY_ENABLE_IF_YOU_KNOW_WHAT_YOURE_DOING = true;
      };
    };

    distrobox = {
      enable = hostPlatform.isLinux;

      settings = let
        volumes = [
          "/nix/store"
          "/etc/profiles/per-user"
          "/etc/static/profiles/per-user"
        ];
      in {
        container_additional_volumes = lib.concatStringsSep " " (map (x: "${x}:${x}:ro") volumes);
      };

      containers = {
        alma.image = "almalinux:latest";
        alpine.image = "alpine:latest";
        arch.image = "archlinux:latest";
        debian.image = "debian:latest";
        rhel.image = "redhat/ubi9:latest";
        suse.image = "opensuse/leap:latest";
        ubuntu.image = "ubuntu:latest";
      };
    };

    emacs = {
      enable = true;
      package = pkgs.emacsWithPackagesFromUsePackage ({
        alwaysEnsure = true;

        config = ''
          ${builtins.readFile ../conf/emacs/init.el}
          ${config.programs.emacs.extraConfig}
        '';

        override = epkgs: epkgs // {
          emsg-blame = epkgs.trivialBuild {
            pname = "emsg-blame";
            version = "unstable-2025-10-23";

            src = pkgs.fetchFromGitHub {
              owner = "ISouthRain";
              repo = "emsg-blame";
              rev = "34f981394aecb3747f0c95c4ae359e8f35c7c677";
              hash = "sha256-4TzUsZPXXPhgNKsVhVnmeFDtTHRpD1mEZYRRwcUv/ec=";
            };

            packageRequires = [ epkgs.async ];
          };
        };

        package = let
          darwinPackage = pkgs.emacs-unstable.overrideAttrs (old: {
            patches = old.patches ++ [ ./frame-transparency.patch ];
          });
        in if hostPlatform.isDarwin then darwinPackage
           else if isHeadless then pkgs.emacs-igc
           else pkgs.emacs-igc-pgtk;

        extraEmacsPackages = epkgs: (config.programs.emacs.extraPackages epkgs) ++ (with epkgs; [
          treesit-grammars.with-all-grammars
        ]);

      } // (if hostPlatform.isDarwin
            then { configAsDefaultInitFile = true; }
            else { defaultInitFile = true; }));
    };

    eza = {
      enable = true;
      git = true;
    };

    firefox = {
      enable = !isHeadless;
      configPath = "${config.xdg.configHome}/mozilla/firefox";
    };

    foot = {
      enable = hostPlatform.isLinux && !isHeadless;
      server.enable = true;

      settings = {
        bell.system = "no";
        mouse.hide-when-typing = "yes";
        scrollback.lines = 1000000;

        key-bindings.pipe-command-output =
          ''[sh -c "f=$(mktemp); cat - > $f; emacsclient -c $f; rm $f"] Control+Shift+g'';

        main = {
          term = "xterm-256color";
          pad = "20x20";
        };
      };
    };

    gh = {
      enable = true;
      extensions = with pkgs; [
        gh-eco
      ];
    };

    gh-dash.enable = true;

    git = {
      enable = true;
      signing.format = null;

      ignores = [
        ".claude"
        ".vscode"
      ];

      settings = {
        inherit user;

        advice.addEmptyPathspec = false;
        core.editor = ''${config.home.sessionVariables.EDITOR}'';
        init.defaultBranch = "master";
        push.autoSetupRemote = true;

        diff.guitool = "meld";
        "difftool \"meld\"".cmd = ''meld "$LOCAL" "$REMOTE"'';

        merge.guitool = "meld";
        "mergetool \"meld\"".cmd = ''meld "$LOCAL" "$BASE" "$REMOTE" --output "$MERGED"'';

        alias = {
          a = "add";
          aa = "add -A";
          br = "branch";
          ci = "commit";
          co = "checkout";
          d = "diff";
          ds = "diff --staged";
          f = "fuzzy";
          pl = "pull";
          ps = "push";
          psf = "push --force-with-lease";
          r = "rebase";
          rev = "rev-parse HEAD";
          st = "status";
          sw = "switch";
          wt = "worktree";
        };
      };
    };

    hyprlock = {
      enable = hostPlatform.isLinux && !isHeadless;
      settings = {
        auth."fingerprint:enabled" = true;
        general = {
          grace = 3;
          hide_cursor = true;
        };
      };
    };

    less = {
      enable = true;
      config = ''
        #env

        #command
        / forw-search ^W
      '';
    };

    mergiraf = {
      enable = true;
      enableGitIntegration = true;
    };

    nh = {
      enable = true;
      flake = "${config.home.homeDirectory}/src/dotfiles";
    };

    numbat = {
      enable = true;
      settings = {
        intro-banner = "short";
        prompt = "> ";
      };
    };

    opencode = {
      enable = enableSocial;
      package = pkgs.writeShellApplication (let
        clipboardLibraryPath = lib.optionalString hostPlatform.isLinux
          (pkgs.lib.makeLibraryPath [ pkgs.wayland ]);
      in {
        name = "opencode";
        text = ''
          set -a
          # shellcheck disable=SC1091
          source "${config.age.secrets.opencode-env.path}"
          set +a
          # OpenCode's native clipboard backend dlopen()s libwayland-client.so.0
          # at runtime; the prebuilt binary does not carry it, so without this
          # Wayland clipboard reads (Ctrl+V paste of text/images) return
          # "Unsupported" and are silently ignored.
          export LD_LIBRARY_PATH="${clipboardLibraryPath}''${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
          ${opencode}/bin/opencode "$@"
        '';

        derivationArgs = {
          doInstall = true;
          installPhase = ''
            ln -s ${opencode}/share $out/share
          '';
        };
      });
    };

    readline = {
      enable = true;
      extraConfig = ''
      set editing-mode vi
    '';
    };

    sketchybar = {
      enable = !isHeadless && hostPlatform.isDarwin;
      config = {
        source = pkgs.runCommand "sketchybar-config" { } ''
          cp -r ${../conf/sketchybar} $out
          chmod -R u+w $out
          substituteInPlace $out/sketchybarrc \
            --replace-fail "/etc/profiles/per-user/armeen" "/etc/profiles/per-user/${user.login}"
        '';
        recursive = true;
      };
    };

    skim = {
      enable = true;
      defaultOptions = [ "--ansi" ];
    };

    ssh = {
      enable = true;
      package = pkgs.openssh;
      enableDefaultConfig = false;

      settings = {
        "*" = {
          compression = true;
          controlMaster = "auto";
          controlPath = "~/.ssh/sockets/cm-%r@%h:%p";
        };

        "carbon.armeen.xyz" = {
          proxyCommand = "${pkgs.cloudflared}/bin/cloudflared access ssh --hostname %h";
        };
      };

      extraOptionOverrides = lib.optionalAttrs hostPlatform.isDarwin {
        SecurityKeyProvider = "/usr/lib/ssh-keychain.dylib";
      };
    };

    television = {
      enable = true;
      enableZshIntegration = false;
    };

    translate-shell = {
      enable = enableSocial;
      settings = {
        hl = "en";
        tl = [ "hi" ];
      };
    };

    tofi = {
      enable = hostPlatform.isLinux && !isHeadless;
      settings = let
        inherit (config.lib.stylix.colors.withHashtag) base00 base03 base0A;
        # Fully transparent; stylix paints the translucent window colour behind
        # each result/prompt as well, which stacks into a visible slab.
        transparent = "#00000000";
      in {
        "width" = "100%";
        "height" = "100%";
        "border-width" = 0;
        "outline-width" = 0;
        "padding-left" = "35%";
        "padding-top" = "35%";
        "result-spacing" = 25;
        "num-results" = 5;
        "font" = lib.mkForce "${pkgs.fira-code}/share/fonts/truetype/FiraCode-VF.ttf";
        # Drop the box behind the results and the prompt.
        "default-result-background" = lib.mkForce transparent;
        "prompt-background" = lib.mkForce transparent;
        "input-background" = lib.mkForce transparent;
        # Highlight the selected result as a yellow block with dark text.
        "selection-background" = lib.mkForce base0A;
        "selection-color" = lib.mkForce base00;
        # The prompt recedes to the grey the selection text used to be.
        "prompt-color" = lib.mkForce base03;
      };
    };

    vscode = {
      enable = !isHeadless;
      package = if hostPlatform.isLinux then pkgs.vscode.fhs else pkgs.vscode;
      mutableExtensionsDir = false;

      profiles.default = {
        extensions = with pkgs.vscode-extensions; [
          eamodio.gitlens
          llvm-vs-code-extensions.lldb-dap
          llvm-vs-code-extensions.vscode-clangd
          mkhl.direnv
          ms-vscode.cpptools-extension-pack
          ms-vscode.hexeditor
          ms-vsliveshare.vsliveshare
          vscodevim.vim
        ] ++ pkgs.vscode-utils.extensionsFromVscodeMarketplace [
          {
            name = "llama-vscode";
            publisher = "ggml-org";
            version = "0.0.70";
            sha256 = "sha256-uYXtH+fuKz8mPtFF3k2kM4JflyYXaB9zK5UXDUUrSGc=";
          }
        ] ++ lib.optionals hostPlatform.isLinux [
          ms-vscode.cpptools
        ];

        userSettings = {
          "vim.foldfix" = true;
          "clangd.path" = "${pkgs.llvmPackages_21.clang-tools}/bin/clangd";
          "C_Cpp.intelliSenseEngine" = "disabled";
          "[cpp]" = {
            "editor.defaultFormatter" = "llvm-vs-code-extensions.vscode-clangd";
          };
        };
      };
    };

    yazi = {
      enable = true;
      shellWrapperName = "y";
    };

    yt-dlp = {
      enable = enableSocial && hostPlatform.isLinux;
      settings = {
        embed-thumbnail = true;
        downloader = "aria2c";
        downloader-args = "aria2c:'-c -x8 -s8 -k1M'";
      };
    };

    zathura = {
      enable = hostPlatform.isLinux && !isHeadless;
      mappings = {
        "<C-i>" = "recolor";
      };
    };

    zellij = {
      enable = true;
      enableZshIntegration = false;

      settings = {
        pane_frames = false;
        default_layout = "compact";

        keybinds = {
          unbind = "Ctrl g";

          normal = {
            "bind \"Ctrl m\"" = { SwitchToMode = "Locked"; };
          };

          locked."bind \"Ctrl m\"" = { SwitchToMode = "Normal"; };
        };
      };
    };
  };

  # ControlMaster sockets live here; ssh does not create the directory itself,
  # so make sure it exists before the first connection.
  home.file.".ssh/sockets/.keep".text = "";
}
