{ config
, lib
, pkgs
, enableSocial
, isHeadless
, isStandalone
, ...
}:

let
  inherit (pkgs.stdenv) hostPlatform;
in {
  imports = [
    ./home.nix
    ./programs.nix
    ./completions.nix
    ./services.nix
    ./starship.nix
    ./systemd.nix
    ./waybar.nix
    ./wayland.nix
    ./xdg.nix
    ./zsh.nix
  ] ++ lib.optionals isStandalone [
    ../modules/shared/nix.nix
    ../modules/shared/stylix.nix
  ];

  targets.genericLinux.enable = hostPlatform.isLinux && isStandalone;

  targets.darwin = lib.optionalAttrs hostPlatform.isDarwin {
    currentHostDefaults = {
      "com.microsoft.VSCode" = {
        ApplePressAndHoldEnabled = false;
      };
    };
  };

  fonts.fontconfig.enable = !isHeadless;
  qt.enable = !isHeadless;

  gtk = {
    enable = !isHeadless;

  } // lib.optionalAttrs hostPlatform.isLinux {
    iconTheme = {
      name = "Rose Pine";
      package = pkgs.rose-pine-icon-theme;
    };
  };

  age = {
    identityPaths = [ "${config.home.homeDirectory}/.ssh/id_ed25519" ];
    secrets = lib.optionalAttrs enableSocial {
      opencode-env = {
        file = ../secrets/opencode.env.age;
      };
    };
  };


} // lib.optionalAttrs (!isHeadless) {
  # This is almost always noise for us.
  stylix.enableReleaseChecks = false;
}
