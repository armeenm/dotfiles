{
  imports = [
    ../shared
    ./base.nix
  ];
}
